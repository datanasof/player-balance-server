package player_gameplay;

public class Player {
	
	private String username;
	private Balance myBalance;
	
	public Player(String username, Balance myBalance) {
		super();
		this.username = username;
		this.myBalance = myBalance;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public Balance getMyBalance() {
		return myBalance;
	}

	public void setMyBalance(Balance myBalance) {
		this.myBalance = myBalance;
	}
	
	private boolean isValidTransaction(int balanceChange){
		
		return true;
	}

}
